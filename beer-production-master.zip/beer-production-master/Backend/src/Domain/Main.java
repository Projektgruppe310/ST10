package Domain;


public class Main{

    public static void main(String[] args) {

        ControlHub controlHub = new ControlHub();
        controlHub.cliCommands();

    }
    
}
